# AGENTS.md - AI 协作者开发指引

本文档帮助所有 AI 理解项目背景与实现规范，以便精准实现需求。

## 项目概述

**AiComic** — AI 动态漫创作平台。从文字剧本到动态漫视频的一站式创作工具。

核心链路：`剧本输入 → AI 分镜 → 画面生成 → 动态化 → 配音配乐 → 合成输出`

## 目录结构

```
AiComic/
├── AGENTS.md           # AI 开发指引
├── SOUL.md            # AI 协作行为规范
├── IDENTITY.md        # 项目身份
├── PROJECT_SPEC.md    # 产品规格
├── .cursorrules       # 编码规范
├── .cursor/rules/     # Cursor 项目知识库
├── apps/              # 应用代码（monorepo）
│   ├── backend/       # Python/FastAPI 后端
│   │   ├── api/      # API 路由
│   │   ├── models/   # 数据模型
│   │   ├── services/ # 核心服务（分镜/图像/动态化/音频/合成）
│   │   ├── config/   # 配置管理（settings.py）
│   │   └── utils/    # 工具函数
│   └── frontend/     # Next.js 前端（待开发）
├── scripts/           # CrewAI 脚本模板库
│   ├── templates/    # 脚本模板（crud/api/page/multiagent）
│   └── common/       # 公共模块
├── config/            # 环境变量模板（.env.example）
├── docs/              # PRD、产品需求文档
├── 原型/              # 功能原型设计
├── test/              # 测试文件
└── 营销方案/          # 营销输出
```

## 需求与设计在哪

- **产品需求与路线图**：`PROJECT_SPEC.md`
- **功能/原型设计**：`docs/`、`原型/`
- **实现前**：先确认需求，再写代码；改代码时同步更新文档

## Bot 协作职责

| Bot | 职责 | 输出目录 |
|-----|------|---------|
| 状态监控 | 总协调、任务分发、进度跟踪 | 任务板 |
| 产品经理 | 竞品分析、PRD、原型设计 | `docs/`、`原型/` |
| 研发 | 技术方案、CrewAI 脚本、代码实现 | `apps/backend/` |
| 营销 | 竞品验证、营销方案 | `营销方案/` |

**协作流程**：状态监控收任务 → 分配给对应 Bot → Bot 完成后更新任务板 → 状态监控通知

## 实现习惯

1. **新功能**：先看设计/PRD，再实现；改代码时同步更新文档
2. **CrewAI 脚本**：优先使用 `scripts/templates/` 中的模板
3. **代码位置**：`apps/backend/` 目录下按功能模块划分（api/、services/、models/）
4. **git push 规范**：每次代码更新后必须执行 `git add . && git commit && git push`
5. **commit 格式**：`feat: [需求名] - [简要描述]`
6. **大文件**（>800行）：优先抽取为组件/子模块再改

## Red Lines

- 不泄露私有数据；不未经确认执行破坏性命令（用 `trash` 而非 `rm`）；有疑虑先问。

## External vs Internal

- **可自由做**：读文件、搜索、在本工作区修改与运行
- **先询问**：发邮件/对外发布、任何离开本机的操作

## 语言规范

- 始终使用简体中文进行回复和注释
